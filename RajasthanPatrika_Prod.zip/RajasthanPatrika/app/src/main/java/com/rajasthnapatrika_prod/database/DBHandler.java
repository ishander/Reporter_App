package com.rajasthnapatrika_prod.database;

public class DBHandler {

    public String Id = "";
	public String Status = "";
    public String Status_process = "";
	public String Story_Type = "";
	public String Heading = "";
	public String Sub_heading = "";
	public String Introduction = "";
	public String Body = "";
	public String Personality_topic = "";
	public String Priority = "";
	public String Scope = "";
	public String Category = "";
	public String Domain = "";
    public String Time = "";
    public String PlaceName = "";
    public String Nid = "";
	public String notification_id = "";
	public String Required_more = "";
	public String Content_url = "";
	public long   MiliSec;
	public String Thumbnail = "";
	public String isRead = "";
	public String publish_status_print = "";
	public String publish_status_tv = "";
	public String latitute = "";
	public String publish_status_web = "";
	public String longitute = "";
	public String Img_size = "";
	public String Vid_size = "";
	public String Aud_size = "";

	public String Aud_size(String Aud_size)
	{
		return this.Aud_size = Aud_size;
	}

	public String Vid_size(String Vid_size)
	{
		return this.Vid_size = Vid_size;
	}

	public String Img_size(String Img_size)
	{
		return this.Img_size = Img_size;
	}


	public String notification_id(String notification_id)
	{
		return this.notification_id = notification_id;
	}

	public String latitute(String latitute)
	{
		return this.latitute = latitute;
	}

	public String longitute(String longitute)
	{
		return this.longitute = longitute;
	}


	public String publish_status_print(String publish_status_print)
	{
		return this.publish_status_print = publish_status_print;
	}

	public String publish_status_tv(String publish_status_tv)
	{
		return this.publish_status_tv = publish_status_tv;
	}

	public String publish_status_web(String publish_status_web)
	{
		return this.publish_status_web = publish_status_web;
	}

	public String Thumbnail(String Thumbnail)
	{
		return this.Thumbnail = Thumbnail;
	}

	public long MiliSec(long MiliSec)
	{
		return this.MiliSec = MiliSec;
	}

    public String Id(String Id)
    {
        return this.Id = Id;
    }

    public String PlaceName(String PlaceName)
    {
        return this.PlaceName = PlaceName;
    }

    public String Content_url(String Content_url)
    {
        return this.Content_url = Content_url;
    }

	public String Required_more(String Required_more)
	{
		return this.Required_more = Required_more;
	}

	public String Nid(String Nid)
	{
		return this.Nid = Nid;
	}

    public String Time(String Time)
    {
        return this.Time = Time;
    }

	public String Status(String Status)
	{
		return this.Status = Status;
	}

    public String isRead(String isRead)
    {
        return this.isRead = isRead;
    }

	public String Status_process(String Status_process)
	{
		return this.Status_process = Status_process;
	}


	public String Story_Type(String Story_Type)
	{
		return this.Story_Type = Story_Type;
	}

	public String Heading(String Heading)
	{
		return this.Heading = Heading;
	}

	public String Sub_heading(String Sub_heading)
	{
		return this.Sub_heading = Sub_heading;
	}

	public String Introduction(String Introduction)
	{
		return this.Introduction = Introduction;
	}

	public String Body(String Body)
	{
		return this.Body = Body;
	}

	public String Personality_topic(String Personality_topic)
	{
		return this.Personality_topic = Personality_topic;
	}

	public String Priority(String Priority)
	{
		return this.Priority = Priority;
	}

	public String Scope(String Scope)
	{
		return this.Scope = Scope;
	}

	public String Category(String Category)
	{
		return this.Category = Category;
	}

	public String Domain(String Domain)
	{
		return this.Domain = Domain;
	}
	
}
