package com.rajasthnapatrika_prod.pick;

public class CustomGallery {

	public String sdcardPath;
	public boolean isSeleted = false;

}
