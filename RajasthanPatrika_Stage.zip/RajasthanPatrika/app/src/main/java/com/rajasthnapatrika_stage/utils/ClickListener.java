/**
 * 
	My name is sumit garg

 */
package com.rajasthnapatrika_stage.utils;

import android.view.View;

public interface ClickListener {
    public void onClick(View view, int position);

    public void onLongClick(View view, int position);
}

