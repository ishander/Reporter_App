package com.rajasthnapatrika_stage.pick;

public class CustomGallery {

	public String sdcardPath;
	public boolean isSeleted = false;

}
